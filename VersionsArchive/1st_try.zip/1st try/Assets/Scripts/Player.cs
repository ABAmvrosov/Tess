﻿using UnityEngine;
using System.Collections;

public class Player {

	public SideType side;

}
